export default function handler(req, res) {
    res.status(200).json({
        status: true,
        message: "PRO API RUNNING 🚀",
        endpoints: {
            telegram: "/api/tg?username=",
            number: "/api/number?num=",
            vehicle: "/api/vehicle?num="
        }
    });
}
export default function handler(req, res) {
    const { num } = req.query;

    if (!num) {
        return res.status(400).json({ status: false, message: "Vehicle number required" });
    }

    res.status(200).json({
        status: true,
        vehicle: num,
        owner: "Hidden",
        state: "India",
        type: "Car/Bike",
        note: "Demo Data"
    });
}
export default async function handler(req, res) {
    const { username } = req.query;

    if (!username) {
        return res.status(400).json({ status: false, message: "Username required" });
    }

    try {
        const response = await fetch(`https://t.me/${username}`);
        const html = await response.text();

        const name = html.match(/og:title" content="(.*?)"/)?.[1];
        const bio = html.match(/og:description" content="(.*?)"/)?.[1];
        const image = html.match(/og:image" content="(.*?)"/)?.[1];

        res.status(200).json({ status: true, username, name, bio, profile: image });

    } catch {
        res.status(500).json({ status: false });
    }
}
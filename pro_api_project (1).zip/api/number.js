export default function handler(req, res) {
    const { num } = req.query;

    if (!num) {
        return res.status(400).json({ status: false, message: "Number required" });
    }

    res.status(200).json({
        status: true,
        number: num,
        country: "India",
        operator: "Jio/Airtel/VI",
        note: "Demo Data"
    });
}